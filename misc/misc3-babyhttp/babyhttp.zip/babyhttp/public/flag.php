<?php
$pass = "Hi!NUAACTF";
$flag = "NUAACTF{WH4T_d0_y0u_kn0w_H334}";